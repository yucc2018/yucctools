from setuptools import setup

setup(name='yucctools',
        version='0.0.1',
        description='useful tools, such as logger, time, vimrc',
        url='',
        author='Chen-Chen Yu',
        author_email='6506666@gmail.com',
        license='MIT',
        packages=['yucctools'],
        zip_safe=False)

